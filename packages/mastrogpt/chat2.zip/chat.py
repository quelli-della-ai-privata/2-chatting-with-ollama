import os, requests as req, json, socket, traceback

def stream(args, lines):
  sock = args.get("STREAM_HOST")
  port = int(args.get("STREAM_PORT"))
  out = ""
  with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((sock, port))
    try:
      for line in lines:
        dec = json.loads(line.decode("utf-8")).get("response")
        msg = {"output": dec }
        out += dec
        s.sendall(json.dumps(msg).encode("utf-8"))
    except Exception as e:
      traceback.print_exc(e)
      out = str(e)
  return out

def models(args):
  apihost = args.get("OLLAMA_API_HOST", os.getenv("OLLAMA_API_HOST"))
  res = req.get(f"{apihost}/api/tags").json()
  for i in res['models']:
    yield i['name']

def ask(args, msg):
    apihost = args.get("OLLAMA_API_HOST", os.getenv("OLLAMA_API_HOST"))
    lines = req.post(f"{apihost}/api/generate", json=msg, stream=True).iter_lines()
    stream(args, lines)

MODEL = "llama3.1:8b"
USAGE = """Welcome to Ollama.
Select a model with '@<model>'
List the available models with '@'"""
  
def chat(args):
  out = USAGE
  inp = args.get("input", "")
  if inp == "@":
    lines = models(args)
    stream(args,lines)
  elif inp!= "":
    msg = { "model": MODEL, "prompt": inp, "stream": True }
    ask(args, msg)
  return { "output": out, "streaming": True}
