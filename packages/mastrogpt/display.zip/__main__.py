#--web true
#--kind python:default
import display
def main(args):
    return display.display(args)
