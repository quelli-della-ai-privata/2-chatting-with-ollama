#--kind python:default
#--web true
import demo
def main(args):
  return { "body": demo.demo(args) }
